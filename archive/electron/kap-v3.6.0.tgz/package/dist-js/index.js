"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const electron_util_1 = require("electron-util");
const electron_log_1 = __importDefault(require("electron-log"));
const electron_updater_1 = require("electron-updater");
const to_milliseconds_1 = __importDefault(require("@sindresorhus/to-milliseconds"));
require("./windows/load");
require("./utils/sentry");
const settings_1 = require("./common/settings");
const plugins_1 = require("./plugins");
const tray_1 = require("./tray");
const devices_1 = require("./utils/devices");
const analytics_1 = require("./common/analytics");
const global_accelerators_1 = require("./global-accelerators");
const open_files_1 = require("./utils/open-files");
const system_permissions_1 = require("./common/system-permissions");
const deep_linking_1 = require("./utils/deep-linking");
const recording_history_1 = require("./recording-history");
const remote_states_1 = require("./remote-states");
const export_1 = require("./export");
const manager_1 = require("./windows/manager");
const protocol_1 = require("./utils/protocol");
const aperture_1 = require("./aperture");
const next_loader_1 = require("./utils/next-loader");
const ipc_handlers_1 = require("./ipc-handlers");
const filesToOpen = [];
let onExitCleanupComplete = false;
electron_1.app.commandLine.appendSwitch('--enable-features', 'OverlayScrollbar');
electron_1.app.on('open-file', (event, path) => {
    event.preventDefault();
    if (electron_1.app.isReady()) {
        (0, analytics_1.track)('editor/opened/running');
        (0, open_files_1.openFiles)(path);
    }
    else {
        filesToOpen.push(path);
    }
});
const initializePlugins = async () => {
    if (electron_1.app.isPackaged) {
        try {
            await plugins_1.plugins.upgrade();
        }
        catch (error) {
            console.log(error);
        }
    }
};
const checkForUpdates = () => {
    if (!electron_1.app.isPackaged) {
        return false;
    }
    const checkForUpdates = async () => {
        var _a;
        try {
            await electron_updater_1.autoUpdater.checkForUpdates();
        }
        catch (error) {
            (_a = electron_updater_1.autoUpdater.logger) === null || _a === void 0 ? void 0 : _a.error(error);
        }
    };
    // For auto-update debugging in Console.app
    electron_updater_1.autoUpdater.logger = electron_log_1.default;
    // @ts-expect-error
    electron_updater_1.autoUpdater.logger.transports.file.level = 'info';
    setInterval(checkForUpdates, (0, to_milliseconds_1.default)({ hours: 1 }));
    checkForUpdates();
    return true;
};
// Prepare the renderer once the app is ready
(async () => {
    var _a;
    await electron_1.app.whenReady();
    require('./utils/errors').setupErrorHandling();
    // Initialize remote states
    (0, remote_states_1.setupRemoteStates)();
    (0, ipc_handlers_1.registerIpcHandlers)();
    (0, protocol_1.setupProtocol)();
    electron_1.app.dock.hide();
    electron_1.app.setAboutPanelOptions({ copyright: 'Copyright © Wulkano' });
    // Ensure the app is in the Applications folder
    (0, electron_util_1.enforceMacOSAppLocation)();
    // Show tray icon and register shortcuts immediately so the app feels responsive
    (0, tray_1.initializeTray)();
    (0, global_accelerators_1.initializeGlobalAccelerators)();
    (0, devices_1.initializeDevices)();
    (0, analytics_1.initializeAnalytics)();
    (0, export_1.setUpExportsListeners)();
    // Prepare the Next.js renderer and plugin upgrades in parallel
    await Promise.all([
        (0, next_loader_1.prepareRenderer)('./renderer'),
        initializePlugins()
    ]);
    (0, tray_1.setRendererReady)();
    if (!electron_1.app.isDefaultProtocolClient('kap')) {
        electron_1.app.setAsDefaultProtocolClient('kap');
    }
    if (filesToOpen.length > 0) {
        (0, analytics_1.track)('editor/opened/startup');
        (0, open_files_1.openFiles)(...filesToOpen);
        (0, recording_history_1.hasActiveRecording)();
    }
    else if (!(await (0, recording_history_1.hasActiveRecording)()) &&
        !electron_1.app.getLoginItemSettings().wasOpenedAtLogin &&
        (await (0, system_permissions_1.ensureScreenCapturePermissions)()) &&
        (!settings_1.settings.get('recordAudio') || (0, system_permissions_1.hasMicrophoneAccess)())) {
        (_a = manager_1.windowManager.cropper) === null || _a === void 0 ? void 0 : _a.open();
    }
    checkForUpdates();
})();
electron_1.app.on('window-all-closed', () => {
    electron_1.app.dock.hide();
});
electron_1.app.on('will-finish-launching', () => {
    electron_1.app.on('open-url', (event, url) => {
        event.preventDefault();
        (0, deep_linking_1.handleDeepLink)(url);
    });
});
electron_1.app.on('before-quit', async (event) => {
    if (!onExitCleanupComplete) {
        event.preventDefault();
        await (0, aperture_1.stopRecordingWithNoEdit)();
        (0, recording_history_1.cleanPastRecordings)();
        onExitCleanupComplete = true;
        electron_1.app.quit();
    }
});
//# sourceMappingURL=index.js.map